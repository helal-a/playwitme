package com.bookmyevent365.playwitme;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.Log;

/**
 * Created by User on 08/10/2016.
 */
public class Background {

    private Bitmap image;
    private int x, y, dx;

    public Background(Bitmap res)
    {
        image = res;
        dx = GamePanel.MOVESPEED;
    }
    public void update()
    {
        x+=dx;
       // Log.d("Background","x = "+x);
        if(x < - GamePanel.WIDTH){
            x=0;
        }
    }
    public void draw(Canvas canvas)
    { //Log.d("Background playwitme", "canvas X = "+x+" y="+y);
        canvas.drawBitmap(image, x, y,null);
        if(x<0)
        {
            canvas.drawBitmap(image, x+GamePanel.WIDTH, y, null);
        }
    }

}
