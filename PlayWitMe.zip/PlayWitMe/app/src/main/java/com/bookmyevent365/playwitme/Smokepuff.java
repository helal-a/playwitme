package com.bookmyevent365.playwitme;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * Created by User on 08/10/2016.
 */
public class Smokepuff extends GameObject {
    public int r;
    private int alpha = 255;

    public Smokepuff(int x, int y) {
        r = 5;
        super.x = x;
        super.y = y;
    }

    public void update() {
        x -= 10;
    }

    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.GRAY);
        paint.setStyle(Paint.Style.FILL);
       // paint.setAlpha(alpha/2); // added by me

        canvas.drawCircle(x - r, y - r, r, paint);
        canvas.drawCircle(x - r + 2, y - r - 2, r, paint);
        canvas.drawCircle(x - r + 4, y - r + 1, r, paint);
    }
}
